lux.caps <- NULL
  
.onLoad <- function(libname, pkgname)
{
  path <- system.file("javascript", "lux_plot.js", package="rcloud.lux")
  cat(path)
  caps <- rcloud.install.js.module("lux_plot",
                                   paste(readLines(path), collapse='\n'))
  lux.caps <<- caps
}
